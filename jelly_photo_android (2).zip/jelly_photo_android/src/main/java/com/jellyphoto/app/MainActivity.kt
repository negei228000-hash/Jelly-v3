package com.jellyphoto.app

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt
import kotlin.math.sqrt

class MainActivity : Activity(), SensorEventListener {

    private val accent = 0xFFE32E33.toInt()
    private val pickCode = 42

    private lateinit var cfg: AppSettings
    private lateinit var jelly: JellyView
    private lateinit var sensorManager: SensorManager

    private lateinit var root: FrameLayout
    private lateinit var menuScreen: View
    private lateinit var settingsScreen: View
    private lateinit var gameScreen: View
    private lateinit var brushPanel: LinearLayout
    private lateinit var toastView: TextView
    private var screen = 0 // 0 меню, 1 настройки, 2 игра

    private val buttons = ArrayList<Button>()
    private val labels = ArrayList<TextView>()
    private val hints = ArrayList<TextView>()
    private val seeks = ArrayList<SeekBar>()

    private lateinit var drawBtn: Button
    private lateinit var darkBtn: Button
    private lateinit var pinBtn: Button
    private lateinit var materialBtn: Button
    private lateinit var blurBtn: Button
    private lateinit var loupeBtn: Button
    private lateinit var vibBtn: Button
    private lateinit var shakeSeek: SeekBar
    private lateinit var grabSeek: SeekBar
    private lateinit var shakeLabel: TextView
    private lateinit var grabLabel: TextView

    private var hasPrev = false
    private var prevX = 0f
    private var prevY = 0f
    private var prevZ = 0f

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = AppSettings(this)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager

        jelly = JellyView(this, cfg)
        jelly.onGrab = { if (cfg.vibration) vibrate(20) }

        root = FrameLayout(this)
        menuScreen = buildMenu()
        settingsScreen = buildSettings()
        gameScreen = buildGame()
        root.addView(menuScreen, matchParent())
        root.addView(settingsScreen, matchParent())
        root.addView(gameScreen, matchParent())
        setContentView(root)

        applyTheme()
        syncSettings()
        showScreen(0)
    }

    private fun matchParent() = FrameLayout.LayoutParams(
        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)

    private fun rowLp(top: Int = 0, width: Int = LinearLayout.LayoutParams.MATCH_PARENT) =
        LinearLayout.LayoutParams(width, LinearLayout.LayoutParams.WRAP_CONTENT).also {
            it.topMargin = dp(top)
        }

    // ---------- элементы интерфейса ----------

    private fun newButton(text: String, small: Boolean = false): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.stateListAnimator = null
        if (small) {
            b.textSize = 14f
            b.minWidth = 0
            b.minimumWidth = 0
            b.minHeight = dp(54)
            b.minimumHeight = dp(54)
            b.setPadding(dp(2), 0, dp(2), 0)
        } else {
            b.textSize = 18f
            b.minHeight = dp(60)
            b.minimumHeight = dp(60)
        }
        buttons.add(b)
        return b
    }

    private fun styleButton(b: Button) {
        val dark = cfg.darkTheme
        val normal = if (dark) 0xFF333338.toInt() else 0xFFF0F0F2.toInt()
        val bg = GradientDrawable()
        bg.cornerRadius = dp(16).toFloat()
        bg.setColor(if (b.isSelected) accent else normal)
        b.background = bg
        b.setTextColor(
            if (b.isSelected) Color.WHITE
            else if (dark) 0xFFF5F5F7.toInt() else 0xFF1A1A1F.toInt()
        )
    }

    private fun setActive(b: Button, on: Boolean) {
        b.isSelected = on
        styleButton(b)
    }

    private fun newLabel(text: String, size: Float): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.gravity = Gravity.CENTER
        labels.add(t)
        return t
    }

    private fun newHint(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        hints.add(t)
        return t
    }

    private fun newSeek(max: Int): SeekBar {
        val s = SeekBar(this)
        s.max = max
        s.progressTintList = ColorStateList.valueOf(accent)
        s.thumbTintList = ColorStateList.valueOf(accent)
        seeks.add(s)
        return s
    }

    private fun toggleButton(onToggle: () -> Unit): Button {
        val b = newButton("")
        b.setOnClickListener {
            onToggle()
            cfg.save()
            syncSettings()
        }
        return b
    }

    // ---------- главное меню ----------

    private fun buildMenu(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setPadding(dp(32), 0, dp(32), 0)

        box.addView(newLabel("Jelly Photo", 40f))

        val play = newButton("Играть")
        play.setOnClickListener { showScreen(2) }
        box.addView(play, rowLp(48))

        val settings = newButton("Настройки")
        settings.setOnClickListener { showScreen(1) }
        box.addView(settings, rowLp(16))
        return box
    }

    // ---------- настройки ----------

    private fun buildSettings(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(dp(24), dp(32), dp(24), dp(32))

        box.addView(newLabel("Настройки", 32f))

        darkBtn = toggleButton { cfg.darkTheme = !cfg.darkTheme; applyTheme() }
        box.addView(darkBtn, rowLp(24))

        shakeLabel = newLabel("", 18f)
        box.addView(shakeLabel, rowLp(20))
        shakeSeek = newSeek(30)
        shakeSeek.setOnSeekBarChangeListener(seekListener(
            { cfg.shakeStrength = it / 10f; updateSeekLabels() }))
        box.addView(shakeSeek, rowLp(4))
        box.addView(newHint("0% — тряска не действует, 300% — максимум"), rowLp(2))

        grabLabel = newLabel("", 18f)
        box.addView(grabLabel, rowLp(20))
        grabSeek = newSeek(30)
        grabSeek.setOnSeekBarChangeListener(seekListener(
            { cfg.grabStrength = it / 10f; updateSeekLabels() }))
        box.addView(grabSeek, rowLp(4))
        box.addView(newHint("Насколько сильно палец тянет желе. 0% — не тянется"), rowLp(2))

        pinBtn = toggleButton { cfg.pinEdges = !cfg.pinEdges }
        box.addView(pinBtn, rowLp(20))
        box.addView(newHint("Вкл: края выделения стоят на месте, дрожит только середина. Выкл: болтается всё тело."), rowLp(4))

        materialBtn = toggleButton { cfg.material = (cfg.material + 1) % AppSettings.MATERIAL_NAMES.size }
        box.addView(materialBtn, rowLp(20))
        box.addView(newHint("Нажимай, чтобы менять: желе, резина (упругая), вода (долго колышется), пудинг (тягучий)"), rowLp(4))

        blurBtn = toggleButton { cfg.blurUnder = !cfg.blurUnder }
        box.addView(blurBtn, rowLp(20))
        box.addView(newHint("Выкл: под желе остаётся обычная фотка"), rowLp(4))

        loupeBtn = toggleButton { cfg.loupeEnabled = !cfg.loupeEnabled }
        box.addView(loupeBtn, rowLp(20))
        box.addView(newHint("Пока рисуешь, в углу показывается увеличенное место под пальцем"), rowLp(4))

        vibBtn = toggleButton {
            cfg.vibration = !cfg.vibration
            if (cfg.vibration) vibrate(30)
        }
        box.addView(vibBtn, rowLp(20))
        box.addView(newHint("Лёгкая отдача, когда трогаешь желе"), rowLp(4))

        val back = newButton("Назад")
        back.setOnClickListener { showScreen(0) }
        box.addView(back, rowLp(28))

        val scroll = ScrollView(this)
        scroll.addView(box)
        return scroll
    }

    private fun seekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
            if (fromUser) onChange(p)
        }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) { cfg.save() }
    }

    private fun updateSeekLabels() {
        shakeLabel.text = "Сила тряски: " + (cfg.shakeStrength * 100f).roundToInt() + "%"
        grabLabel.text = "Сила растяжки пальцем: " + (cfg.grabStrength * 100f).roundToInt() + "%"
    }

    private fun onOff(on: Boolean) = if (on) "вкл" else "выкл"

    private fun syncSettings() {
        darkBtn.text = "Тёмная тема: " + onOff(cfg.darkTheme)
        setActive(darkBtn, cfg.darkTheme)
        pinBtn.text = "Края закреплены: " + onOff(cfg.pinEdges)
        setActive(pinBtn, cfg.pinEdges)
        materialBtn.text = "Материал: " + AppSettings.MATERIAL_NAMES[cfg.material]
        setActive(materialBtn, false)
        blurBtn.text = "Размытие под выделением: " + onOff(cfg.blurUnder)
        setActive(blurBtn, cfg.blurUnder)
        loupeBtn.text = "Окошко-лупа при рисовании: " + onOff(cfg.loupeEnabled)
        setActive(loupeBtn, cfg.loupeEnabled)
        vibBtn.text = "Вибрация: " + onOff(cfg.vibration)
        setActive(vibBtn, cfg.vibration)
        shakeSeek.progress = (cfg.shakeStrength * 10f).roundToInt()
        grabSeek.progress = (cfg.grabStrength * 10f).roundToInt()
        updateSeekLabels()
    }

    private fun applyTheme() {
        val dark = cfg.darkTheme
        root.setBackgroundColor(if (dark) 0xFF121214.toInt() else Color.WHITE)
        val fg = if (dark) 0xFFF5F5F7.toInt() else 0xFF1A1A1F.toInt()
        val hint = if (dark) 0xFF9A9AA0.toInt() else 0xFF99999F.toInt()
        for (l in labels) l.setTextColor(fg)
        for (h in hints) h.setTextColor(hint)
        for (b in buttons) styleButton(b)
        val panelBg = GradientDrawable()
        panelBg.cornerRadius = dp(16).toFloat()
        panelBg.setColor(if (dark) 0xF2242429.toInt() else 0xF2F3F3F5.toInt())
        brushPanel.background = panelBg
        val toastBg = GradientDrawable()
        toastBg.cornerRadius = dp(14).toFloat()
        toastBg.setColor(if (dark) 0xF55C5C66.toInt() else 0xEB1F1F24.toInt())
        toastView.background = toastBg
        for (s in seeks) {
            s.progressTintList = ColorStateList.valueOf(accent)
            s.thumbTintList = ColorStateList.valueOf(accent)
        }
        jelly.invalidate()
    }

    // ---------- игра ----------

    private fun buildGame(): View {
        val frame = FrameLayout(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(8), dp(12), dp(10))

        // верхняя панель: Меню, Экспорт фото
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        val menu = barButton("Меню") { showScreen(0) }
        menu.layoutParams = LinearLayout.LayoutParams(dp(96), LinearLayout.LayoutParams.WRAP_CONTENT)
            .also { it.setMargins(0, 0, dp(8), 0) }
        top.addView(menu)
        top.addView(barButton("Экспорт фото") { pickPhoto() })
        box.addView(top)

        // поле с фото
        box.addView(jelly, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // панель кисти (видна только в режиме рисования, место занято всегда)
        brushPanel = LinearLayout(this)
        brushPanel.orientation = LinearLayout.VERTICAL
        brushPanel.setPadding(dp(14), dp(10), dp(14), dp(10))
        val brushRow = LinearLayout(this)
        brushRow.orientation = LinearLayout.HORIZONTAL
        brushRow.gravity = Gravity.CENTER_VERTICAL
        val brushLabel = newLabel("Кисть", 16f)
        brushLabel.setPadding(0, 0, dp(12), 0)
        brushRow.addView(brushLabel)
        val seek = newSeek(100)
        seek.progress = 25
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                jelly.brush = (8 + p) * resources.displayMetrics.density
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        brushRow.addView(seek, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        brushPanel.addView(brushRow)
        val panelRow = LinearLayout(this)
        panelRow.orientation = LinearLayout.HORIZONTAL
        panelRow.addView(barButton("Сброс") { jelly.reset() })
        brushPanel.addView(panelRow, rowLp(8))
        brushPanel.visibility = View.INVISIBLE
        box.addView(brushPanel, rowLp(8))

        // нижняя панель: Нарисовать, Готово, Обои
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        drawBtn = barButton("Нарисовать") { toggleDraw() }
        bottom.addView(drawBtn)
        bottom.addView(barButton("Готово") { finishSelection() })
        bottom.addView(barButton("Обои") { chooseWallpaper() })
        box.addView(bottom, rowLp(8))

        frame.addView(box, matchParent())

        // всплывающая подсказка сверху
        toastView = TextView(this)
        toastView.textSize = 15f
        toastView.gravity = Gravity.CENTER
        toastView.setTextColor(Color.WHITE)
        toastView.setPadding(dp(16), dp(12), dp(16), dp(12))
        toastView.alpha = 0f
        val tlp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        tlp.setMargins(dp(32), dp(84), dp(32), 0)
        frame.addView(toastView, tlp)
        return frame
    }

    private fun barButton(text: String, onClick: () -> Unit): Button {
        val b = newButton(text, true)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(4), 0, dp(4), 0)
        b.layoutParams = lp
        return b
    }

    private fun toast(s: String) {
        toastView.animate().cancel()
        toastView.text = s
        toastView.alpha = 1f
        toastView.animate().alpha(0f).setStartDelay(1600).setDuration(400).start()
    }

    private fun setDraw(on: Boolean) {
        jelly.drawMode = on
        setActive(drawBtn, on)
        brushPanel.visibility = if (on) View.VISIBLE else View.INVISIBLE
    }

    private fun toggleDraw() {
        if (!jelly.hasPhoto()) { toast("Сначала выбери фото"); return }
        setDraw(!jelly.drawMode)
    }

    private fun finishSelection() {
        if (jelly.makeJelly()) {
            setDraw(false)
            toast("Готово! Трогай и тряси")
        } else {
            toast("Сначала обведи область (кнопка Нарисовать)")
        }
    }

    // ---------- экраны ----------

    private fun showScreen(s: Int) {
        if (screen == 1) cfg.save()
        screen = s
        menuScreen.visibility = if (s == 0) View.VISIBLE else View.GONE
        settingsScreen.visibility = if (s == 1) View.VISIBLE else View.GONE
        gameScreen.visibility = if (s == 2) View.VISIBLE else View.GONE
        if (s == 1) syncSettings()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (screen != 0) showScreen(0) else super.onBackPressed()
    }

    // ---------- вибрация и сенсор ----------

    @Suppress("DEPRECATION")
    private fun vibrate(ms: Int) {
        val v = getSystemService(VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            v.vibrate(ms.toLong())
        }
    }

    override fun onResume() {
        super.onResume()
        val acc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (acc != null) sensorManager.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME)
        hasPrev = false
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
        cfg.save()
    }

    override fun onSensorChanged(event: SensorEvent) {
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        if (!hasPrev) {
            prevX = x; prevY = y; prevZ = z
            hasPrev = true
            return
        }
        val jx = x - prevX
        val jy = y - prevY
        val jz = z - prevZ
        prevX = x; prevY = y; prevZ = z
        val mag = sqrt(jx * jx + jy * jy + jz * jz)
        if (mag > 0.8f && screen == 2) jelly.shake(-jx * 40f, jy * 40f)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    // ---------- обои ----------

    private fun chooseWallpaper() {
        if (!jelly.hasPhoto()) { toast("Сначала выбери фото"); return }
        AlertDialog.Builder(this)
            .setTitle("Поставить на обои")
            .setItems(arrayOf(
                "Живые обои (желе двигается)",
                "Картинка: главный экран",
                "Картинка: экран блокировки",
                "Картинка: оба"
            )) { _, which ->
                if (which == 0) applyLiveWallpaper() else applyWallpaper(which - 1)
            }
            .show()
    }

    private fun applyLiveWallpaper() {
        toast("Готовлю живые обои...")
        Thread {
            val ok = jelly.exportScene(filesDir)
            runOnUiThread {
                if (!ok) {
                    toast("Сначала сделай желе: Нарисовать, потом Готово")
                } else {
                    try {
                        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                        i.putExtra(
                            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            ComponentName(this, JellyPhotoWallpaperService::class.java)
                        )
                        startActivity(i)
                    } catch (e: Exception) {
                        try {
                            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                        } catch (e2: Exception) {
                            toast("Открой Настройки, Обои, Живые обои, Jelly Photo")
                        }
                    }
                }
            }
        }.start()
    }

    private fun applyWallpaper(which: Int) {
        val dm = resources.displayMetrics
        val bmp = jelly.snapshot(dm.widthPixels, dm.heightPixels)
        if (bmp == null) { toast("Нет картинки"); return }
        val flag = when (which) {
            0 -> WallpaperManager.FLAG_SYSTEM
            1 -> WallpaperManager.FLAG_LOCK
            else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
        }
        toast("Ставлю обои...")
        Thread {
            try {
                WallpaperManager.getInstance(this).setBitmap(bmp, null, true, flag)
                runOnUiThread { toast("Обои установлены") }
            } catch (e: Exception) {
                runOnUiThread { toast("Не получилось поставить обои") }
            }
        }.start()
    }

    // ---------- выбор фото ----------

    private fun pickPhoto() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(Intent.createChooser(i, "Фото"), pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickCode && resultCode == RESULT_OK) {
            val uri = data?.data
            val bmp = if (uri != null) loadPhoto(uri) else null
            if (bmp != null) {
                setDraw(false)
                jelly.setPhoto(bmp)
                toast("Фото загружено. Жми Нарисовать и обведи область")
            } else {
                toast("Не удалось открыть это фото")
            }
        }
    }

    private fun loadPhoto(uri: Uri): Bitmap? {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 2400) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return null

            var degrees = 0f
            try {
                contentResolver.openInputStream(uri)?.use {
                    val exif = ExifInterface(it)
                    when (exif.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> degrees = 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> degrees = 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> degrees = 270f
                    }
                }
            } catch (e: Exception) {
                degrees = 0f
            }
            if (degrees != 0f) {
                val m = Matrix()
                m.postRotate(degrees)
                val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                bmp.recycle()
                bmp = rotated
            }
            return bmp
        } catch (e: Exception) {
            return null
        }
    }
}
