package com.jellyphoto.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max

// Одно желейное тело для живых обоев (та же физика, что в JellyView).
class JellyBody(
    val bmp: Bitmap, val fill: Bitmap,
    val left: Float, val top: Float, val cols: Int, val rows: Int
) {
    private val spring = 60f
    private val couple = 420f
    private val damp = 3.0f
    private val edgePin = 6f

    val n = (cols + 1) * (rows + 1)
    val rest = FloatArray(n * 2)
    val cur = FloatArray(n * 2)
    val disp = FloatArray(n * 2)
    val vel = FloatArray(n * 2)
    val edge = BooleanArray(n)

    init {
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        for (j in 0..rows) {
            for (i in 0..cols) {
                val idx = j * (cols + 1) + i
                rest[idx * 2] = left + w * i / cols
                rest[idx * 2 + 1] = top + h * j / rows
                edge[idx] = i == 0 || j == 0 || i == cols || j == rows
            }
        }
    }

    // true = всё успокоилось
    fun step(dt: Float, cfg: AppSettings, maxD: Float): Boolean {
        val mm = cfg.mult()
        val pinned = cfg.pinEdges
        val sBase = spring * mm[0] * (if (pinned) 1f else 2.5f)
        val cpl = couple * mm[1]
        val dBase = damp * mm[2]
        val stride = (cols + 1) * 2
        for (y in 0..rows) {
            for (x in 0..cols) {
                val idx = y * (cols + 1) + x
                val k = idx * 2
                var sx = 0f
                var sy = 0f
                var cnt = 0
                if (x > 0) { sx += disp[k - 2]; sy += disp[k - 1]; cnt++ }
                if (x < cols) { sx += disp[k + 2]; sy += disp[k + 3]; cnt++ }
                if (y > 0) { sx += disp[k - stride]; sy += disp[k - stride + 1]; cnt++ }
                if (y < rows) { sx += disp[k + stride]; sy += disp[k + stride + 1]; cnt++ }
                val pin = pinned && edge[idx]
                val sp = if (pin) sBase * edgePin else sBase
                val dp = if (pin) dBase * 4f else dBase
                val ax = -sp * disp[k] + cpl * (sx / cnt - disp[k]) - dp * vel[k]
                val ay = -sp * disp[k + 1] + cpl * (sy / cnt - disp[k + 1]) - dp * vel[k + 1]
                vel[k] += ax * dt
                vel[k + 1] += ay * dt
            }
        }
        var maxV = 0f
        var maxDisp = 0f
        for (k in 0 until n * 2) {
            vel[k] = vel[k].coerceIn(-1800f, 1800f)
            disp[k] = (disp[k] + vel[k] * dt).coerceIn(-maxD, maxD)
            maxV = max(maxV, abs(vel[k]))
            maxDisp = max(maxDisp, abs(disp[k]))
        }
        return maxV < 2f && maxDisp < 0.5f
    }

    fun poke(x: Float, y: Float, ivx: Float, ivy: Float, radius: Float) {
        val r2 = radius * radius
        for (idx in 0 until n) {
            val k = idx * 2
            val dx = rest[k] - x
            val dy = rest[k + 1] - y
            val dd = dx * dx + dy * dy
            if (dd < r2 * 4f) {
                val f = exp(-dd / r2)
                vel[k] += ivx * f
                vel[k + 1] += ivy * f
            }
        }
    }

    fun shake(ix: Float, iy: Float) {
        for (idx in 0 until n) {
            vel[idx * 2] += ix
            vel[idx * 2 + 1] += iy
        }
    }

    fun drawMesh(canvas: Canvas, paint: Paint) {
        for (k in 0 until n * 2) cur[k] = rest[k] + disp[k]
        canvas.drawBitmapMesh(bmp, cols, rows, cur, 0, null, 0, paint)
    }
}
