package com.jellyphoto.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// Живые обои: берут сцену, сохранённую кнопкой Обои -> Живые, и трясут желе.
class JellyPhotoWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = PhotoEngine()

    inner class PhotoEngine : Engine(), SensorEventListener {

        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        private var cfg = AppSettings(applicationContext)

        private var base: Bitmap? = null
        private var bodies = ArrayList<JellyBody>()
        private var sw = 0
        private var sh = 0
        private var scale = 1f
        private var tx = 0f
        private var ty = 0f
        private var sceneStamp = -1L

        private var isShown = false
        private var running = false
        private var calmFrames = 0
        private var lastTime = 0L

        private var hasTouch = false
        private var lastTouchX = 0f
        private var lastTouchY = 0f
        private var hasPrev = false
        private var prevX = 0f
        private var prevY = 0f
        private var prevZ = 0f
        private var lastXOffset = -1f

        private val sensorManager: SensorManager by lazy {
            getSystemService(SENSOR_SERVICE) as SensorManager
        }

        private val frame = object : Runnable {
            override fun run() {
                if (!isShown) {
                    running = false
                    return
                }
                val now = System.nanoTime()
                val dt = min((now - lastTime) / 1.0e9f, 0.033f)
                lastTime = now
                val b = base
                val maxD = if (b != null) min(b.width, b.height) * 0.4f else 100f
                var calm = true
                for (body in bodies) {
                    if (!body.step(dt, cfg, maxD)) calm = false
                }
                drawFrame()
                if (calm) calmFrames++ else calmFrames = 0
                if (calmFrames > 20 && !hasTouch) {
                    running = false
                    return
                }
                handler.postDelayed(this, 16)
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(true)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            sw = width
            sh = height
            loadScene()
            drawFrame()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            isShown = visible
            if (visible) {
                cfg = AppSettings(applicationContext)
                val meta = File(filesDir, "wp_meta.txt")
                val stamp = if (meta.exists()) meta.lastModified() else 0L
                if (sw > 0 && stamp != sceneStamp) loadScene()
                val acc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                if (acc != null) {
                    sensorManager.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME)
                }
                hasPrev = false
                drawFrame()
            } else {
                sensorManager.unregisterListener(this)
                handler.removeCallbacks(frame)
                running = false
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            isShown = false
            handler.removeCallbacks(frame)
            running = false
            sensorManager.unregisterListener(this)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            isShown = false
            handler.removeCallbacks(frame)
            sensorManager.unregisterListener(this)
            base?.recycle()
            base = null
            super.onDestroy()
        }

        // ---------- сцена ----------

        private fun loadScene() {
            val meta = File(filesDir, "wp_meta.txt")
            base?.recycle()
            base = null
            bodies = ArrayList()
            sceneStamp = if (meta.exists()) meta.lastModified() else 0L
            if (!meta.exists()) return
            try {
                val lines = meta.readLines().filter { it.isNotBlank() }
                val b = BitmapFactory.decodeFile(File(filesDir, "wp_base.jpg").path) ?: return
                base = b
                for (i in 1 until lines.size) {
                    val p = lines[i].trim().split(" ")
                    val jb = BitmapFactory.decodeFile(File(filesDir, "wp_j${i - 1}.png").path) ?: continue
                    val fb = BitmapFactory.decodeFile(File(filesDir, "wp_f${i - 1}.png").path) ?: continue
                    bodies.add(JellyBody(jb, fb, p[0].toFloat(), p[1].toFloat(), p[2].toInt(), p[3].toInt()))
                }
            } catch (e: Exception) {
                base = null
            }
            val bb = base
            if (bb != null && sw > 0 && sh > 0) {
                scale = max(sw.toFloat() / bb.width, sh.toFloat() / bb.height)
                tx = (sw - bb.width * scale) / 2f
                ty = (sh - bb.height * scale) / 2f
            }
        }

        private fun kick() {
            calmFrames = 0
            if (!running && isShown) {
                running = true
                lastTime = System.nanoTime()
                handler.post(frame)
            }
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = if (Build.VERSION.SDK_INT >= 26) holder.lockHardwareCanvas()
                else holder.lockCanvas()
            } catch (e: Exception) {
                canvas = null
            }
            if (canvas == null) return
            try {
                canvas.drawColor(Color.BLACK)
                val b = base
                if (b != null) {
                    canvas.save()
                    canvas.translate(tx, ty)
                    canvas.scale(scale, scale)
                    canvas.drawBitmap(b, 0f, 0f, paint)
                    if (cfg.blurUnder) {
                        for (body in bodies) canvas.drawBitmap(body.fill, body.left, body.top, paint)
                    }
                    for (body in bodies) body.drawMesh(canvas, paint)
                    canvas.restore()
                }
            } catch (e: Exception) {
                // кадр пропущен
            } finally {
                try {
                    holder.unlockCanvasAndPost(canvas)
                } catch (e: Exception) {
                    // поверхность уже закрыта
                }
            }
        }

        // ---------- ввод ----------

        private fun pokeAll(x: Float, y: Float, ivx: Float, ivy: Float) {
            val b = base ?: return
            val rad = min(b.width, b.height) * 0.2f
            for (body in bodies) body.poke(x, y, ivx, ivy, rad)
        }

        private fun shakeAll(ix: Float, iy: Float) {
            val g = cfg.shakeStrength
            if (g <= 0f) return
            for (body in bodies) body.shake(ix * g, iy * g)
        }

        override fun onTouchEvent(event: MotionEvent) {
            val x = (event.x - tx) / scale
            val y = (event.y - ty) / scale
            val g = cfg.grabStrength
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    hasTouch = true
                    lastTouchX = x
                    lastTouchY = y
                    pokeAll(x, y, 0f, 300f * g)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = x - lastTouchX
                    val dy = y - lastTouchY
                    lastTouchX = x
                    lastTouchY = y
                    pokeAll(x, y, dx * 25f * g, dy * 25f * g)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> hasTouch = false
            }
            kick()
        }

        override fun onOffsetsChanged(
            xOffset: Float, yOffset: Float, xOffsetStep: Float, yOffsetStep: Float,
            xPixelOffset: Int, yPixelOffset: Int
        ) {
            if (lastXOffset >= 0f) {
                val delta = xOffset - lastXOffset
                if (abs(delta) > 0.0001f) {
                    shakeAll(-delta * 400f, 0f)
                    kick()
                }
            }
            lastXOffset = xOffset
        }

        override fun onSensorChanged(event: SensorEvent) {
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]
            if (!hasPrev) {
                prevX = x; prevY = y; prevZ = z
                hasPrev = true
                return
            }
            val jx = x - prevX
            val jy = y - prevY
            val jz = z - prevZ
            prevX = x; prevY = y; prevZ = z
            val mag = sqrt(jx * jx + jy * jy + jz * jz)
            if (mag > 0.8f) {
                shakeAll(-jx * 40f, jy * 40f)
                kick()
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
}
